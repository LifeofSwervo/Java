class Node
{
    public char data;
    public Node leftChild;
    public Node rightChild;

    /**
     * - Display node, used to display data.
     */
    public void displayNode()
    {
        System.out.println(data);
    }

}
